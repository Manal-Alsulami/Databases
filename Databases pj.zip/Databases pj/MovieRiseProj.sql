CREATE SCHEMA MovieRise;

CREATE TABLE MovieRise.Branch
( BranchNo VARCHAR(5) NOT NULL,
 City VARCHAR(20),
 Street VARCHAR(20),
 ZipCode INT(5),
CONSTRAINT Branch_PK PRIMARY KEY (BranchNo)
);
  
 CREATE TABLE MovieRise.Staff
 (StaffID INT(8) NOT NULL,
 fName VARCHAR(15),
 lName VARCHAR(15),
 Position VARCHAR(20) ,
 Salary DECIMAL(8,2),
 BranchNo VARCHAR(5),
 CONSTRAINT Staff_PK PRIMARY KEY (StaffID),
 CONSTRAINT Staff_FK FOREIGN key (BranchNo) REFERENCES Branch(BranchNo) ON DELETE CASCADE );

CREATE TABLE MovieRise.Coustomer
( CoustomerID INT(10) NOT NULL,
Day VARCHAR(4),
Month VARCHAR(4),
Year INT(4),
fName VARCHAR(15),
lName VARCHAR(15),
CoustomerPhonNo INT(10),
CoustomerEmail VARCHAR(40),
CONSTRAINT Coustomer_PK PRIMARY KEY (CoustomerID));

CREATE TABLE MovieRise.Movie
( MovieName VARCHAR(70) NOT NULL,
AgeLimit INT(2),
Director VARCHAR(15),
 StaffID INT(8),
 CONSTRAINT Movie_PK PRIMARY KEY(MovieName),
 CONSTRAINT Movie_FK FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE);
 
 CREATE TABLE MovieRise.MovieActors
 ( MovieName VARCHAR(70) NOT NULL,
  Actor VARCHAR(15) NOT NULL,
  CONSTRAINT MovieActors_PK PRIMARY KEY(MovieName,Actor),
  CONSTRAINT MovieActors_FK FOREIGN KEY (MovieName) REFERENCES Movie(MovieName) ON DELETE CASCADE);
 
 CREATE TABLE MovieRise.MovieGenre
 ( MovieName VARCHAR(70) NOT NULL,
 MovieGenre VARCHAR(35) NOT NULL,
CONSTRAINT MovieGenre_PK PRIMARY KEY (MovieName,MovieGenre),
CONSTRAINT MovieGenre_FK FOREIGN KEY (MovieName) REFERENCES Movie(MovieName) ON DELETE CASCADE);
 
 CREATE TABLE MovieRise.Ticket
 (  TicketID VARCHAR(8) NOT NULL,
 TicketType VARCHAR(15),
 Day VARCHAR(4),
 Month VARCHAR(4),
 Year INT(4),
ShowTime VARCHAR(5),
TheaterNo INT(3),
SeatNo INT(3),
MovieName VARCHAR(70),
StaffID INT(8),
CoustomerID INT(10),
CONSTRAINT Ticket_PK PRIMARY KEY (TicketID),
CONSTRAINT Ticket_FK1 FOREIGN KEY (MovieName) REFERENCES Movie(MovieName) ON DELETE CASCADE,
CONSTRAINT Ticket_FK2 FOREIGN KEY (StaffID) REFERENCES Staff(StaffID) ON DELETE CASCADE,
CONSTRAINT Ticket_FK3 FOREIGN KEY (CoustomerID) REFERENCES Coustomer(CoustomerID) ON DELETE CASCADE
 ); 
 
INSERT INTO movierise.branch
 VALUES (
 'B001' ,
 'London' ,
 '22 Deer Rd' ,
 '12345');
 INSERT INTO movierise.branch
 VALUES (
 'B002' ,
 'Aberdeen' ,
 '16 Argyll St' ,
 '12354');
INSERT INTO movierise.branch
 VALUES (
 'B003' ,
 'Glasgow' ,
 '163 Main St' ,
 '13452');
INSERT INTO movierise.branch
 VALUES (
 'B004' ,
 'Bristol' ,
 '32 Manse Rd' ,
 '12435');
INSERT INTO movierise.branch
 VALUES (
 'B005' ,
 'London' ,
 '56 Clover Dr' ,
 '12344'); 
 
INSERT INTO movierise.staff
 VALUES (
 '12345687' ,
 'John' ,
 'Max' ,
 'Manager',
 '1000.12' ,
 'B002');
 INSERT INTO movierise.staff
 VALUES (
 '65438711' ,
 'Ann' ,
 'Whaite' ,
 'Staff',
 '899.99' ,
 'B002');
 INSERT INTO movierise.staff
 VALUES (
 '45321678' ,
 'David' ,
 'Lam',
 'Staff',
 '3000.50' ,
 'B001');
 INSERT INTO movierise.staff
 VALUES (
 '12287765' ,
 'Mary' ,
 'Howe' ,
 'Staff',
 '2400.00' ,
 'B003');
 INSERT INTO movierise.staff
 VALUES (
 '54321678' ,
 'Susan' ,
 'Tar' ,
 'Staff',
 '9900.00' ,
 'B004');
 INSERT INTO movierise.staff
 VALUES (
 '65432189' ,
 'Leon' ,
 'Jack' ,
 'Staff',
 '1500.50' ,
 'B001');
 
INSERT INTO movierise.coustomer
 VALUES (
 '234567189' ,
 '04' ,
 'Sept' ,
 '2001',
 'Jack' ,
 'Leem',
 '309861542',
 'Jl01@gmail.com');
INSERT INTO movierise.coustomer
 VALUES (
 '12345662' ,
 '03' ,
 'Jan' ,
 '1995',
 'Jisoo' ,
 'Kim',
 '990154239',
 'Jik01@gmail.com');
INSERT INTO movierise.coustomer
 VALUES (
 '45672348' ,
 '15' ,
 'Oct' ,
 '1989',
 'Lara' ,
 'Omar',
 '503889127',
 'lao77@gmail.com');
INSERT INTO movierise.coustomer
 VALUES (
 '34215643' ,
 '27' ,
 'Nov' ,
 '2003',
 'Sandy' ,
 'Park',
 '307655249',
 'spark@gmail.com');
INSERT INTO movierise.coustomer
 VALUES (
 '83645825' ,
 '13' ,
 'Agu' ,
 '1997',
 'Mark' ,
 'Lee',
 '985477246',
 'Mar0k@gmail.com');
 
INSERT INTO movierise.Movie
VALUES ('Titanic','15','James Cameron','12345687');
INSERT INTO movierise.Movie
VALUES ('Interstellar','13','Christopher ','65438711');
INSERT INTO movierise.Movie
VALUES ('one day','16','Lone Scherfig','45321678');
INSERT INTO movierise.Movie
VALUES ('Fatherhood','13','paul Weits','12287765');
INSERT INTO movierise.Movie
VALUES ('Cruella','13','Craig Gillespie','54321678');
INSERT INTO movierise.Movie
VALUES ('Ratatouille','7','Brad Bird','54321678');
     
INSERT INTO MovieRise.MovieActors
VALUES('Titanic','Leonardo ');
INSERT INTO MovieRise.MovieActors
VALUES('Titanic','Kate Winslet '); 
INSERT INTO MovieRise.MovieActors
VALUES('Interstellar','Matthtuu ');
INSERT INTO MovieRise.MovieActors
VALUES('One day','Anne Hathauuay '); 
INSERT INTO MovieRise.MovieActors
VALUES('Fatherhood','Kevin hart '); 
INSERT INTO MovieRise.MovieActors
VALUES('Cruella','Emma Stone ');
INSERT INTO MovieRise.MovieActors
VALUES('Ratatouille','Patton ');

INSERT INTO MovieRise.MovieGenre
VALUES( 'Titanic','Romance');      
INSERT INTO MovieRise.MovieGenre
VALUES( 'Interstellar','Mastery');
INSERT INTO MovieRise.MovieGenre
VALUES( 'One day','Drama');
INSERT INTO MovieRise.MovieGenre
VALUES( 'Fatherhood','Comedy');
INSERT INTO MovieRise.MovieGenre
VALUES( 'Cruella','Adventure');
INSERT INTO MovieRise.MovieGenre
VALUES( 'Ratatouille','Fantasy');

INSERT INTO MovieRise.Ticket
VALUES ('50843100','Standard','17','4','2022','20:15','1','725','Titanic','12345687','234567189');     
INSERT INTO MovieRise.Ticket
VALUES ('66856230','VIP','13','6','2022','08:15','3','908','Interstellar','65438711','12345662');
INSERT INTO MovieRise.Ticket
VALUES ('95768170','VIP','8','7','2022','07:55','5','120','one day','45321678',  '45672348');
INSERT INTO MovieRise.Ticket
VALUES ('09812675','Gold','1','4','2022','14:00','7','654','Fatherhood','12287765', '34215643');
INSERT INTO MovieRise.Ticket
VALUES ('98723456','Gold','8','11','2022','12:45','2','910','Cruella','54321678',  '83645825');

UPDATE MovieRise.Staff
SET Salary=(Salary*5.5)
WHERE StaffID='12345687';
SELECT *
FROM MovieRise.Staff;

DELETE FROM MovieRise.Staff
WHERE StaffID='54321678';
SELECT *
FROM MovieRise.Staff;
      
      -- the queries:
    -- 1  using DISTINCT
      SELECT position
      FROM MovieRise.Staff;
      
      -- List the types of positions
      SELECT DISTINCT position
      FROM MovieRise.Staff;
      
      -- 2 using GROUP BY and ORDER BY .
      -- List the number of employee in each position
      SELECT position  , COUNT(StaffID) AS count
      FROM MovieRise.Staff
      GROUP BY position
      ORDER BY position DESC;
      
      -- 3 using GROUP BY with HAVING .
       SELECT * 
      FROM movierise.Movie;
      -- List the number of movies in each ageLimit grater than 10.
      SELECT AgeLimit ,COUNT(MovieName)As movies
      FROM movierise.Movie
      GROUP BY AgeLimit
      HAVING AgeLimit> 10
      ORDER BY AgeLimit;
      
-- 4 using subquerys
      SELECT *
      FROM MovieRise.MovieGenre;
      SELECT *
      FROM MovieRise.MovieActors;
      
            -- List the movie name and actor in specific genre type (drama and Romance).
      SELECT *
      FROM MovieRise.MovieActors
      WHERE MovieName IN (SELECT MovieName
                          FROM MovieRise.MovieGenre
                          WHERE MovieGenre = 'Drama' OR MovieGenre = 'Romance')
	  ORDER BY MovieName ASC;

	-- 5 using subquerys 
	SELECT *
	FROM MovieRise.Branch;

	SELECT *
	FROM MovieRise.Staff;

	-- List all staff information who work in the london city .
	SELECT *
	FROM MovieRise.Staff
	WHERE BranchNo  IN (SELECT BranchNo
                    FROM MovieRise.Branch
                    WHERE City = 'London');
 
-- list all information of ticket when the month was 4 
 SELECT * 
 FROM MovieRise.ticket WHERE Month ='4' ;
 
 -- list all staff salary less than 2500
 SELECT StaffID,Salary 
 FROM MovieRise.staff WHERE Salary <2500 ;
 
 -- list all the number of theater ASC
 SELECT * 
 FROM MovieRise.ticket ORDER BY TheaterNo ;
 
 -- list all employees with their tickets sold 
 SELECT staffID,TicketType ,TicketID  
 FROM MovieRise.ticket ORDER BY StaffID,TicketType;
 
 -- list all movie's name with showtime 
SELECT movie.MovieName,ticket.ShowTime ,ticket.Day,ticket.Month,ticket.Year
 FROM MovieRise.movie  , MovieRise.ticket ;